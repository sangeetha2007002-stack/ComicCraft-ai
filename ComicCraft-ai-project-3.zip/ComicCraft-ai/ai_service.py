import os

def generate_story(idea, style='Funny'):
    key = os.getenv('GEMINI_API_KEY', '').strip()
    if key:
        try:
            from google import genai
            client = genai.Client(api_key=key)
            prompt = f'Create a family-friendly 6-panel comic story. Idea: {idea}. Style: {style}. Give a title and numbered panels with short descriptions and dialogue.'
            response = client.models.generate_content(model='gemini-2.5-flash', contents=prompt)
            return {'title': f'ComicCraft: {idea[:45]}', 'content': response.text.strip()}
        except Exception:
            pass
    return {'title': f'ComicCraft: {idea[:45]}', 'content': f'Panel 1 - Setup: {idea}\nPanel 2 - A surprising problem appears.\nPanel 3 - The hero gets an idea.\nPanel 4 - The plan creates a funny situation.\nPanel 5 - Everyone works together and solves the problem.\nPanel 6 - Happy ending: everyone celebrates.'}
