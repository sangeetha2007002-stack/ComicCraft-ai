from fastapi import FastAPI, Form, Request
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from ai_service import generate_story
from pdf_generator import create_pdf

app = FastAPI(title='ComicCraft - AI Comic Story Creator')
app.mount('/static', StaticFiles(directory='static'), name='static')
templates = Jinja2Templates(directory='templates')

@app.get('/', response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse('index.html', {'request': request})

@app.post('/generate', response_class=HTMLResponse)
async def generate(request: Request, idea: str = Form(...), style: str = Form('Funny')):
    story = generate_story(idea, style)
    return templates.TemplateResponse('comic.html', {'request': request, 'story': story})

@app.post('/download')
async def download(title: str = Form(...), content: str = Form(...)):
    path = create_pdf(title, content)
    return FileResponse(path, filename='comiccraft_story.pdf', media_type='application/pdf')
