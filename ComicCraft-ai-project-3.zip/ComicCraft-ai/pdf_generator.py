from pathlib import Path
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet

def create_pdf(title, content):
    path = Path('comiccraft_story.pdf')
    styles = getSampleStyleSheet()
    doc = SimpleDocTemplate(str(path), pagesize=A4)
    elements = [Paragraph(title, styles['Title']), Spacer(1, 20)]
    for line in content.splitlines():
        if line.strip(): elements += [Paragraph(line, styles['BodyText']), Spacer(1, 8)]
    doc.build(elements)
    return str(path)
