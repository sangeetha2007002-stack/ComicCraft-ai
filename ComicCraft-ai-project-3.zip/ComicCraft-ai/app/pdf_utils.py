from pathlib import Path
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.styles import ParagraphStyle

BASE_DIR = Path(__file__).resolve().parent.parent
OUTPUT_DIR = BASE_DIR / "generated"
OUTPUT_DIR.mkdir(exist_ok=True)

def create_pdf(prompt: str, story: str) -> str:
    output = OUTPUT_DIR / "comiccraft_story.pdf"
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        "ComicTitle", parent=styles["Title"], alignment=TA_CENTER, spaceAfter=18
    )
    body = styles["BodyText"]

    doc = SimpleDocTemplate(str(output), pagesize=A4)
    story_flow = [
        Paragraph("ComicCraft – AI Comic Story", title_style),
        Paragraph(f"<b>Idea:</b> {prompt}", body),
        Spacer(1, 12),
    ]

    for line in story.splitlines():
        safe = line.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        if safe.strip():
            story_flow.append(Paragraph(safe, body))
            story_flow.append(Spacer(1, 6))

    doc.build(story_flow)
    return str(output)
