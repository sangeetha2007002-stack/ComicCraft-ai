# Optional Hugging Face Diffusers image-generation module.
# This file is intentionally optional because Diffusers models can be large.
#
# Install separately when needed:
# pip install diffusers transformers accelerate torch
#
# Example:
# from diffusers import StableDiffusionPipeline
# import torch
#
# def generate_image(prompt: str, output_path: str):
#     pipe = StableDiffusionPipeline.from_pretrained(
#         "runwayml/stable-diffusion-v1-5"
#     )
#     image = pipe(prompt).images[0]
#     image.save(output_path)
