import os
from google import genai
from google.genai import types

SYSTEM_PROMPT = '''
You are ComicCraft, an AI comic story writer.
Create a short, family-friendly comic story from the user's idea.

Return:
TITLE: a short title
CHARACTERS: 2-4 characters
PANELS:
Panel 1: Scene description | Dialogue: ...
Panel 2: Scene description | Dialogue: ...
Panel 3: Scene description | Dialogue: ...
Panel 4: Scene description | Dialogue: ...
Panel 5: Scene description | Dialogue: ...
Panel 6: Scene description | Dialogue: ...
MORAL: one short lesson

Keep the language simple and make each panel visually clear.
'''

async def generate_comic_story(prompt: str) -> str:
    api_key = os.getenv("GEMINI_API_KEY")
    model = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")

    if not api_key or api_key == "your_gemini_api_key_here":
        return (
            "DEMO MODE\n\n"
            "TITLE: The Brave Little Fox\n"
            "CHARACTERS: Fox, Owl, Rabbit\n\n"
            "PANELS:\n"
            "Panel 1: A little fox enters an enchanted forest | Dialogue: "
            ""I will explore carefully!"\n"
            "Panel 2: The fox meets an owl | Dialogue: "Follow the safe path."\n"
            "Panel 3: The fox helps a rabbit find its way home.\n"
            "Panel 4: The animals work together to cross a small stream.\n"
            "Panel 5: They reach a sunny clearing and celebrate.\n"
            "Panel 6: The fox smiles and thanks its friends.\n\n"
            "MORAL: Courage and teamwork help us solve problems.\n\n"
            "Add a real GEMINI_API_KEY in .env to generate stories from your own prompts."
        )

    client = genai.Client(api_key=api_key)
    response = client.models.generate_content(
        model=model,
        contents=f"{SYSTEM_PROMPT}\n\nUser idea: {prompt}",
        config=types.GenerateContentConfig(
            temperature=0.8,
            max_output_tokens=1200,
        ),
    )
    return response.text or "No story was generated."
