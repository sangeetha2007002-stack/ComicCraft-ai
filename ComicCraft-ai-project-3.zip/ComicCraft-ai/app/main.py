from pathlib import Path
from fastapi import FastAPI, Form, Request
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.templating import Jinja2Templates
from dotenv import load_dotenv

from app.routes import generate_comic_story
from app.pdf_utils import create_pdf

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent.parent
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))

app = FastAPI(title="ComicCraft - AI Comic Story Creator")


@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


@app.post("/generate", response_class=HTMLResponse)
async def generate(request: Request, prompt: str = Form(...)):
    story = await generate_comic_story(prompt)
    return templates.TemplateResponse(
        "comic.html",
        {"request": request, "story": story, "prompt": prompt},
    )


@app.post("/download-pdf")
async def download_pdf(prompt: str = Form(...), story: str = Form(...)):
    output = create_pdf(prompt, story)
    return FileResponse(
        output,
        media_type="application/pdf",
        filename="comiccraft_story.pdf",
    )
