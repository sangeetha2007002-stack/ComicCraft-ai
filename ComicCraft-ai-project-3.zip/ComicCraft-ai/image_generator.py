def make_image_prompt(panel_text):
    return 'Family-friendly colorful 2D comic panel: ' + panel_text
