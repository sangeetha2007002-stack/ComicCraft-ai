# ComicCraft - AI Comic Story Creator

FastAPI web application for creating short AI comic stories using Gemini models.

## Run locally
pip install -r requirements.txt
uvicorn main:app --reload

Open http://127.0.0.1:8000

## Deployment
Start command:
uvicorn main:app --host 0.0.0.0 --port $PORT
