from ai_service import generate_story

def create_comic(idea, style='Funny'):
    return generate_story(idea, style)
